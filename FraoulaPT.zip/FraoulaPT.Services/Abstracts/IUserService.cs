﻿using FraoulaPT.DTOs.UserDTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FraoulaPT.Services.Abstracts
{
    public interface IUserService
    {
        Task Login(LoginDTO login);
        Task Register(RegisterDTO register);
        List<UserDTO> GetAllUser();
        UserDTO GetByUser(string userName);
        Task SignOut();
    }
}
