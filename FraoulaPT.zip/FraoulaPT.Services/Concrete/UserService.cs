﻿using FraoulaPT.DTOs.UserDTOs;
using FraoulaPT.Entity;
using FraoulaPT.Services.Abstracts;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FraoulaPT.Services.Concrete
{
    public class UserService : IUserService
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly SignInManager<AppUser> _signInManager;
        public UserService(UserManager<AppUser> userManager, SignInManager<AppUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }
        public List<UserDTO> GetAllUser()
        {
            throw new NotImplementedException();
        }

        public UserDTO GetByUser(string userName)
        {
            throw new NotImplementedException();
        }

        public async Task Login(LoginDTO login)
        {

            var user = await _userManager.FindByNameAsync(login.UserName);

            if (user == null)
            {
                throw new Exception("Kullanıcı adı hatalı");
            }
            var signInResult = await _signInManager.PasswordSignInAsync(user, login.Password, false, false);
            if (signInResult.Succeeded)
            {
                return;
            }
            else
            {
                throw new Exception("Kullanıcı şifresi hatalı");
            }
        }

        public async Task Register(RegisterDTO register)
        {
            AppUser appUser = new AppUser();
            appUser.UserName = register.UserName;
            appUser.Email = register.Email;
            appUser.PhoneNumber = register.Phone;
            appUser.Status = Core.Enums.Status.Active;
            appUser.CreatedDate = DateTime.Now;
            appUser.ModifiedDate = DateTime.Now;
            //appUser.LockoutEnabled = true;

            var _identityResult = await _userManager.CreateAsync(appUser, register.Password);
            if (_identityResult.Succeeded)
            {
                var user = await _userManager.FindByNameAsync(appUser.UserName);
                await _userManager.AddToRoleAsync(user, "User");
                return;
            }
            else
            {
                string errorText = string.Empty;
                foreach (var item in _identityResult.Errors)
                {
                    errorText += $"{item.Description} , ";
                }
                throw new Exception(errorText.Trim(',', ' '));
            }

        }

        public async Task SignOut()
        {
            await _signInManager.SignOutAsync();
        }
    }
}
