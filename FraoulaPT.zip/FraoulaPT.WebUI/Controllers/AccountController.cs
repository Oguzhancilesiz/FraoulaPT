﻿using FraoulaPT.DTOs.UserDTOs;
using FraoulaPT.Services.Abstracts;
using FraoulaPT.WebUI.Models.Enums;
using FraoulaPT.WebUI.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace FraoulaPT.WebUI.Controllers
{
    public class AccountController : BaseController
    {
        private readonly IUserService _userService;
        public AccountController(IUserService userService)
        {
            _userService = userService;
        }
        [HttpGet]
        public async Task<IActionResult> Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginVM vm)
        {
            if (ModelState.IsValid)
            {
                LoginDTO dto = new LoginDTO();
                dto.UserName = vm.UserName;
                dto.Password = vm.Password;
                try
                {
                    await _userService.Login(dto);
                    ShowMessage("Giriş İşlemi Başarılı", MessageType.success);
                    return RedirectToAction("Index", "Home");
                }
                catch (Exception ex)
                {
                    ShowMessage(ex.Message, MessageType.error);
                }
            }
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(RegisterVM vm)
        {

            if (ModelState.IsValid)
            {
                RegisterDTO dTO = new RegisterDTO();
                dTO.UserName = vm.UserName;
                dTO.Email = vm.Email;
                dTO.Phone = vm.Phone;
                dTO.Password = vm.Password;

                try
                {
                    await _userService.Register(dTO);
                    ShowMessage("Kayıt İşlemi Başarılı", MessageType.success);
                    return RedirectToAction("Login");

                }
                catch (Exception ex)
                {
                    ShowMessage(ex.Message, MessageType.error);

                }
            }
            return View(vm);
        }

        public async Task<IActionResult> SignOut()
        {
            await _userService.SignOut();
            return RedirectToAction("Index", "Home");
        }
    }
}
