﻿namespace FraoulaPT.WebUI.Models.Enums
{
    public enum MessageType
    {
        success,
        error,
        warning,
        info
    }
}
